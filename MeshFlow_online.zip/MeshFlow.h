﻿#include "Mesh.h"
#include <algorithm>
#include <cmath>

#ifndef __VECPT2F__
#define VecPt2f vector<cv::Point2f>
#endif __VECPT2F__

//【参数】特征点搜索半径
#define RADIUS 100
//【参数】滑动窗口的大小
#define BUFFER_SIZE 40  //论文中的buffer大小为40

#ifndef __NODE__
#define __NODE__
struct node {
	VecPt2f features; //特征点
	VecPt2f motions; //对应的运动向量
};
#endif


#ifndef __MESHFLOW__
#define __MESHFLOW__

//顶点轮廓：存储同一个顶点在所有帧的运动向量
//使用队列，来满足滑动窗口
struct VertexProfile {
	std::deque<cv::Point2f> motionVectors;   // v(t) - 使用 deque 实现滑动窗口
	std::deque<cv::Point2f> cumulativePath;  // C(t) = Σv(t)
	std::deque<cv::Point2f> smoothedPath;    // P(t) - 优化后的路径

	//添加新帧运动（自动维护 buffer 大小）
	void addMotion(cv::Point2f motion) {
		// 超出 buffer 大小则删除最旧的
		if (motionVectors.size() >= BUFFER_SIZE) {
			cv::Point2f oldestMotion = motionVectors.front();
			motionVectors.pop_front();

			// ⭐ 关键修正：从所有累积路径中减去最旧的运动
			// 相当于把窗口起点前移一帧
			for (int i = 0; i < cumulativePath.size(); i++) {
				cumulativePath[i] -= oldestMotion;
			}

			// 删掉最旧的累积路径点（因为它现在变成 0 了）
			cumulativePath.pop_front();
			smoothedPath.pop_front();
		}

		// 添加新运动
		motionVectors.push_back(motion);

		// 更新累积路径
		if (cumulativePath.empty()) {
			cumulativePath.push_back(motion);
		}
		else {
			cv::Point2f newC = cumulativePath.back() + motion;
			cumulativePath.push_back(newC);
		}

		// 初始化 smoothed path（后续会被优化覆盖）
		smoothedPath.push_back(cumulativePath.back());
	}

	// 获取当前 buffer 大小
	int size() const {
		return motionVectors.size();
	}
};

//MeshFlow:稳像控制器
//它拿着一堆历史的 Mesh，计算出一条平滑的路径，然后告诉当前的 Mesh 应该怎么变形才能让画面稳下来
class MeshFlow {

private:
	int m_height, m_width;
	int m_quadWidth, m_quadHeight;
	int m_meshheight, m_meshwidth;

	cv::Mat m_source, m_target;
	cv::Mat m_globalHomography;
	Mesh* m_mesh; //原始网格
	Mesh* m_warpedmesh; //变换后的网格
	VecPt2f m_vertexMotion; //网格顶点的运动向量（光流法）
	node n; //node 结构体）：存储特征点（features）和对应的运动向量（motions）

	// ========== 多帧处理相关 ==========
	// 存储所有帧的网格顶点位置
	std::vector<Mesh*> m_meshSequence;  // 每一帧的原始网格
	std::vector<Mesh*> m_warpedMeshSequence;  // 每一帧变形后的网格
	// 存储优化后的网格顶点位置
	std::vector<Mesh*> m_smoothedMeshSequence;  // 路径优化后的网格
	// 路径优化
	double m_lambda;  // 平滑权重（论文中的 λ）
	int m_radius;     // 时间窗口半径
	cv::Point2f OptimizeVertexPath(int frameIdx, int i, int j);

	void SpatialMedianFilter();
	void DistributeMotion2MeshVertexes_MedianFilter();
	void WarpMeshbyMotion();
	cv::Point2f Trans(cv::Mat H, cv::Point2f& pt);

	// ========== 新增：PAPS 数据结构 ==========

	int m_frameCount;  // 当前帧数

	std::vector<cv::Point2f> m_previousSmoothedPath;  // P^(ξ-1) for online
	std::vector<double> m_lambdaHistory;  // 每帧的 lambda_t


public:
	std::vector<VertexProfile> m_vertexProfiles;  // 每个顶点的 profile
	MeshFlow(int width, int height);
	void ReInitialize();

	void Execute();
	void SetFeature(vector<cv::Point2f>& spt, vector<cv::Point2f>& tpt);
	//【修改】
	void SetSource(cv::Mat& src);  //输入帧入口
	void GetMotions(cv::Mat& mapX, cv::Mat& mapY);

	Mesh* GetDestinMesh() { return m_warpedmesh; }

	void GetWarpedSource(cv::Mat& dst, cv::Mat& mapX, cv::Mat& mapY);

	// ========== 多帧处理相关 ==========
	//Getter 方法（访问private）
	Mesh* GetMesh() { return m_mesh; }
	Mesh* GetWarpedMesh() { return m_warpedmesh; }
	// 添加一帧的处理结果
	void AddFrame(Mesh* originalMesh, Mesh* warpedMesh);

	// 执行路径优化
	void OptimizePath(double lambda = 100.0, int radius = 5);

	// 获取优化后的第 frameIdx 帧的映射表
	void GetSmoothedMotions(int frameIdx, cv::Mat& mapx, cv::Mat& mapy);

	// 清空所有帧数据
	void ClearFrames();

	// 获取总帧数
	int GetFrameCount() const { return m_meshSequence.size(); }

	// ========== 新增：PAPS 相关方法 ==========
	void AddFrameMotion(int featureCount = -1);  // 添加当前帧的运动向量到 vertex profiles
	// 优化当前 buffer（替代 SmoothPathsOffline）
	void SmoothCurrentBuffer(double lambda, int radius);
	// 从 buffer 中获取最新的稳定网格
	Mesh* GetStabilizedMeshFromBuffer();

	void SmoothPathsOnline(int bufferSize, double beta);  // 在线平滑（PAPS）
	double PredictLambda();  // 预测 lambda_t（公式 2-3）

	// 生成稳定后的网格（用于 mesh warp）
	Mesh* GetStabilizedMesh(int frameIdx);

	// Getters
	void PrintBufferStatus();
	int GetFrameCount() { return m_frameCount; }

};
#endif