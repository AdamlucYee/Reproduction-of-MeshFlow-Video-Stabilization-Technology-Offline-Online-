﻿// test_video.cpp - 修改后的版本
#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include "MeshFlow.h"
#include "Mesh.h"


using namespace std;

int main(int argc, char** argv) {
    cv::utils::logging::setLogLevel(cv::utils::logging::LOG_LEVEL_WARNING);

    string videoPath = "./test_video/1080_1.mp4";
    int maxFrames = -1;

    if (argc > 1) videoPath = argv[1];
    if (argc > 2) maxFrames = atoi(argv[2]);

    // ========== 1. 打开视频 ==========
    cv::VideoCapture cap(videoPath);
    if (!cap.isOpened()) {
        cerr << "Error: Cannot open video" << endl;
        return -1;
    }

    int width = cap.get(cv::CAP_PROP_FRAME_WIDTH);
    int height = cap.get(cv::CAP_PROP_FRAME_HEIGHT);
    int totalFrames = cap.get(cv::CAP_PROP_FRAME_COUNT);
    double fps = cap.get(cv::CAP_PROP_FPS);

    int numFrames = (maxFrames > 0) ? min(maxFrames, totalFrames) : totalFrames;

    std::cout << "Video info:" << endl;
    std::cout << "  Resolution: " << width << "x" << height << endl;
    std::cout << "  Total frames: " << totalFrames << endl;
    std::cout << "  Processing frames: " << numFrames << endl;

    // ========== 2. 初始化 ==========
    MeshFlow meshflow(width, height);

    // 创建输出视频
    string outputPath = "./output_video/stabilized_online.mp4";
    cv::VideoWriter writer(outputPath, cv::VideoWriter::fourcc('m', 'p', '4', 'v'),
        fps, cv::Size(width, height));

    if (!writer.isOpened()) {
        cerr << "Error: Cannot create output video!" << endl;
        return -1;
    }

    // ========== 创建显示窗口 ==========
    string windowName = "Video Stabilization - Online";
    cv::namedWindow(windowName, cv::WINDOW_NORMAL);
    cv::resizeWindow(windowName, 1280, 360);  // 左右对比显示

    // ========== 3. 在线处理主循环 ==========
    std::cout << "\n========== Online Stabilization ==========\n";

    cv::Mat prevFrame, currFrame;
    cap >> prevFrame;

    cv::Mat mapX(height, width, CV_32FC1);
    cv::Mat mapY(height, width, CV_32FC1);

    bool paused = false;

    // main.cpp - 修改主循环

    for (int frameIdx = 0; frameIdx < numFrames - 1; frameIdx++) {
        cap >> currFrame;
        if (currFrame.empty()) break;

        // 3.1 提取运动
        cv::Mat gray0, gray1;
        cv::cvtColor(prevFrame, gray0, cv::COLOR_BGR2GRAY);
        cv::cvtColor(currFrame, gray1, cv::COLOR_BGR2GRAY);

        vector<cv::Point2f> prevPts, nextPts;
        //【参数】
        cv::goodFeaturesToTrack(gray0, prevPts, 800, 0.01, 10);

        vector<uchar> status;
        vector<float> err;
        cv::calcOpticalFlowPyrLK(gray0, gray1, prevPts, nextPts, status, err);

        vector<cv::Point2f> validPrev, validNext;
        for (int j = 0; j < prevPts.size(); j++) {
            if (status[j]) {
                validPrev.push_back(prevPts[j]);
                validNext.push_back(nextPts[j]);
            }
        }

        // 3.2 计算网格运动
        meshflow.ReInitialize();
        meshflow.SetFeature(validPrev, validNext);
        meshflow.Execute();

        // 3.3 添加到 buffer
        meshflow.AddFrameMotion(validPrev.size());
        int bufferSize = meshflow.m_vertexProfiles[0].size();

        // 3.4 优化 buffer
        if (frameIdx >= BUFFER_SIZE - 1) {
            /*meshflow.SmoothCurrentBuffer(20.0, 7);*/
            //【参数】上一轮迭代的权重
            meshflow.SmoothPathsOnline(BUFFER_SIZE, 1);//beta版本（1.0）
        }

        // 3.5 生成稳定帧
        cv::Mat stabilizedFrame;

        if (frameIdx < BUFFER_SIZE - 1) {
            // 预热阶段：直接输出原帧
            /*stabilizedFrame = prevFrame.clone();*/
            stabilizedFrame = currFrame.clone();

            // ✅ 每 10 帧输出一次（减少控制台刷新）
            if (frameIdx % 10 == 0) {
                std::cout << "[WARMUP] Frame " << frameIdx
                    << " - Buffer: " << bufferSize << "/" << BUFFER_SIZE
                    << " | Features: " << validPrev.size() << endl;
            }
        }
        else {
            // 稳定阶段
            Mesh* regularMesh = meshflow.GetMesh();  // X0（规则网格）
            Mesh* samplingMesh = meshflow.GetStabilizedMeshFromBuffer();  // X0 + (C - P)

            if (samplingMesh) {
                meshWarpRemap(currFrame, stabilizedFrame, mapX, mapY,
                    *regularMesh, *samplingMesh);

                delete samplingMesh;  // 只需要删除 samplingMesh

                if (frameIdx % 10 == 0) {
                    std::cout << "[STABLE] Frame " << frameIdx
                        << " | Buffer: " << bufferSize
                        << " | Features: " << validPrev.size() << std::endl;
                }
            }
            else {
                stabilizedFrame = currFrame.clone();
                std::cout << "[ERROR] Frame " << frameIdx << endl;
            }


        }

        // 3.6 实时显示（左右对比）
        cv::Mat comparison(height, width * 2, CV_8UC3);
        prevFrame.copyTo(comparison(cv::Rect(0, 0, width, height)));
        stabilizedFrame.copyTo(comparison(cv::Rect(width, 0, width, height)));

        // 添加文字标注
        cv::putText(comparison, "Original", cv::Point(20, 50),
            cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 255, 0), 3);
        cv::putText(comparison, "Stabilized", cv::Point(width + 20, 50),
            cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 0, 255), 3);

        string frameText = "Frame: " + to_string(frameIdx);
        cv::putText(comparison, frameText, cv::Point(20, height - 20),
            cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 255, 255), 2);

        string bufferText = "Buffer: " + to_string(bufferSize) + "/40";
        cv::putText(comparison, bufferText, cv::Point(width + 20, height - 20),
            cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 255, 255), 2);

        cv::imshow(windowName, comparison);

        // 3.7 输出到视频文件
        writer.write(stabilizedFrame);

        //3.8 键盘控制（只保留退出）
        char key = cv::waitKey(1);
        if (key == 'q' || key == 27) break;  // 'q' 或 ESC 退出

        ////每 40 帧打印 buffer 状态
        //if (frameIdx % 40 == 0 && frameIdx >= BUFFER_SIZE) {
        //    meshflow.PrintBufferStatus();
        //}

        // 3.9 准备下一帧
        prevFrame = currFrame.clone();
    }


    cout << "\n\n========== Done! ==========\n";
    cout << "Output: " << outputPath << endl;

    writer.release();
    cap.release();
    cv::destroyAllWindows();

    return 0;
}