﻿//检测运动平滑
 
//#include <opencv2/opencv.hpp>
//#include <iostream>
//#include <vector>
//#include <algorithm>
//#include <iomanip>
//#include "MeshFlow.h"
//
//using namespace std;
//
//int main() {
//    cv::utils::logging::setLogLevel(cv::utils::logging::LOG_LEVEL_WARNING);
//    // ========== 读取视频 ==========
//    //【路径】输入
//    cv::VideoCapture cap("./test_video/720_1.mp4");
//    if (!cap.isOpened()) {
//        cerr << "Error: Cannot open video file" << endl;
//        return -1;
//    }
//
//    int width = cap.get(cv::CAP_PROP_FRAME_WIDTH);
//    int height = cap.get(cv::CAP_PROP_FRAME_HEIGHT);
//    int totalFrames = cap.get(cv::CAP_PROP_FRAME_COUNT);
//
//    cout << "Video: " << width << "x" << height << ", " << totalFrames << " frames\n";
//
//    //【参数】设置读取的帧数
//    /*int numFrames = min(90, totalFrames);*/
//    int numFrames = totalFrames;
//
//    vector<cv::Mat> frames;
//
//    for (int i = 0; i < numFrames; i++) {
//        cv::Mat frame;
//        cap >> frame;
//        if (frame.empty()) break;
//        frames.push_back(frame.clone());
//    }
//
//    cout << "Loaded " << frames.size() << " frames\n\n";
//
//    // ========== 创建 MeshFlow 对象 ==========
//    MeshFlow meshflow(width, height);
//
//    cout << "========== Processing frames ==========\n";
//    //设置处理的视频帧数量
//    for (int i = 0; i < frames.size() - 1; i++) {
//        cout << "\n--- Frame " << i << " -> " << i + 1 << " ---\n";
//
//        // 提取特征点
//        cv::Mat gray0, gray1;
//        cv::cvtColor(frames[i], gray0, cv::COLOR_BGR2GRAY);
//        cv::cvtColor(frames[i + 1], gray1, cv::COLOR_BGR2GRAY);
//
//        vector<cv::Point2f> prevPts, nextPts;
//        cv::goodFeaturesToTrack(gray0, prevPts, 500, 0.01, 10);
//
//        vector<uchar> status;
//        vector<float> err;
//        cv::calcOpticalFlowPyrLK(gray0, gray1, prevPts, nextPts, status, err);
//
//        // 过滤特征点
//        vector<cv::Point2f> validPrev, validNext;
//        for (int j = 0; j < prevPts.size(); j++) {
//            if (status[j]) {
//                validPrev.push_back(prevPts[j]);
//                validNext.push_back(nextPts[j]);
//            }
//        }
//
//        cout << "Tracked " << validPrev.size() << " features\n";
//
//        // 重置并设置特征点
//        meshflow.ReInitialize();
//        meshflow.SetFeature(validPrev, validNext);
//
//        // 执行 MeshFlow
//        meshflow.Execute();
//
//        // 添加当前帧的运动到 profiles
//        meshflow.AddFrameMotion();
//    }
//
//    // ========== 执行平滑 ==========
//    cout << "\n========== Executing Path Smoothing ==========\n";
//    double lambda = 5.0;
//    int radius = 5;
//
//    meshflow.SmoothPathsOffline(lambda, radius);
//
//    cout << "\n========== Path Smoothing Completed ==========\n";
//    cout << "Lambda: " << lambda << "\n";
//    cout << "Radius: " << radius << "\n";
//
//    // ========== 方差分析（选择测试帧）==========
//    cout << "\n========== Analyzing Motion Variance ==========\n";
//
//    int meshHeight = meshflow.GetMesh()->height;
//    int meshWidth = meshflow.GetMesh()->width;
//    int frameCount = meshflow.GetFrameCount();
//
//    // 存储每帧的方差
//    vector<pair<int, double>> frameVariances;
//
//    for (int frameIdx = 0; frameIdx < frameCount; frameIdx++) {
//        vector<cv::Point2f> motions;
//
//        // 收集所有顶点在该帧的累积运动
//        for (int i = 0; i < meshHeight; i++) {
//            for (int j = 0; j < meshWidth; j++) {
//                int idx = i * meshWidth + j;
//                cv::Point2f motion = meshflow.m_vertexProfiles[idx].cumulativePath[frameIdx];
//                motions.push_back(motion);
//            }
//        }
//
//        // 计算 X 和 Y 方向的均值
//        double meanX = 0, meanY = 0;
//        for (const auto& m : motions) {
//            meanX += m.x;
//            meanY += m.y;
//        }
//        meanX /= motions.size();
//        meanY /= motions.size();
//
//        // 计算方差
//        double varianceX = 0, varianceY = 0;
//        for (const auto& m : motions) {
//            varianceX += (m.x - meanX) * (m.x - meanX);
//            varianceY += (m.y - meanY) * (m.y - meanY);
//        }
//        varianceX /= motions.size();
//        varianceY /= motions.size();
//
//        double totalVariance = varianceX + varianceY;
//        frameVariances.push_back({ frameIdx, totalVariance });
//
//        cout << "Frame " << frameIdx
//            << ": mean=(" << fixed << setprecision(2) << meanX << "," << meanY << ")"
//            << ", variance=" << totalVariance << "\n";
//    }
//
//    // 按方差排序
//    sort(frameVariances.begin(), frameVariances.end(),
//        [](const auto& a, const auto& b) { return a.second > b.second; });
//
//    cout << "\n========== Top 10 Frames with Largest Variance ==========\n";
//    for (int i = 0; i < min(10, (int)frameVariances.size()); i++) {
//        cout << "  #" << (i + 1) << ": Frame " << frameVariances[i].first
//            << " (variance = " << fixed << setprecision(2) << frameVariances[i].second << ")\n";
//    }
//
//    // 选择方差最大的 5 帧
//    vector<int> testFrames;
//    for (int i = 0; i < min(5, (int)frameVariances.size()); i++) {
//        testFrames.push_back(frameVariances[i].first);
//    }
//    sort(testFrames.begin(), testFrames.end());  // 按时间顺序排序
//
//    cout << "\n========== Selected Test Frames ==========\n";
//    cout << "Using frames: ";
//    for (int f : testFrames) {
//        cout << f << " ";
//    }
//    cout << "\n";
//
//    // ========== 检查累积路径连续性 ==========
//    cout << "\n========== Checking Cumulative Path Continuity ==========\n";
//
//    int testVertex = 0;  // 左上角顶点
//    cout << "Vertex " << testVertex << " cumulative path (frames 50-60):\n";
//    for (int t = 50; t < min(60, frameCount); t++) {
//        cv::Point2f C_t = meshflow.m_vertexProfiles[testVertex].cumulativePath[t];
//        cout << "  Frame " << t << ": C(t) = (" << fixed << setprecision(2)
//            << C_t.x << ", " << C_t.y << ")\n";
//    }
//
//    // ========== 生成测试图像（对比原始和平滑）==========
//    cout << "\n========== Generating Comparison Images ==========\n";
//
//    for (int t : testFrames) {
//        if (t >= frameCount) continue;
//
//        cout << "\n--- Frame " << t << " ---\n";
//
//        // 打印几个顶点的详细信息
//        cout << "Sample vertices:\n";
//        vector<int> sampleVertices = { 0, meshWidth * meshHeight / 2, meshWidth * meshHeight - 1 };
//
//        for (int idx : sampleVertices) {
//            if (idx < meshflow.m_vertexProfiles.size()) {
//                cv::Point2f C_t = meshflow.m_vertexProfiles[idx].cumulativePath[t];
//                cv::Point2f P_t = meshflow.m_vertexProfiles[idx].smoothedPath[t];
//
//                cout << "  Vertex " << idx << ":\n";
//                cout << "    C(t) = (" << fixed << setprecision(2) << C_t.x << ", " << C_t.y << ")\n";
//                cout << "    P(t) = (" << fixed << setprecision(2) << P_t.x << ", " << P_t.y << ")\n";
//                cout << "    Diff = (" << fixed << setprecision(2)
//                    << (P_t.x - C_t.x) << ", " << (P_t.y - C_t.y) << ")\n";
//            }
//        }
//
//        // 计算平均平滑效果
//        double totalDiff = 0.0;
//        int count = 0;
//        for (int idx = 0; idx < meshflow.m_vertexProfiles.size(); idx++) {
//            cv::Point2f C_t = meshflow.m_vertexProfiles[idx].cumulativePath[t];
//            cv::Point2f P_t = meshflow.m_vertexProfiles[idx].smoothedPath[t];
//            double diff = sqrt((P_t.x - C_t.x) * (P_t.x - C_t.x) +
//                (P_t.y - C_t.y) * (P_t.y - C_t.y));
//            totalDiff += diff;
//            count++;
//        }
//        cout << "Average smoothing displacement: " << (totalDiff / count) << " pixels\n";
//
//        // 1. 生成原始累积网格（未平滑）
//        Mesh* originalMesh = new Mesh(height, width, meshWidth, meshHeight);
//
//        for (int i = 0; i < meshHeight; i++) {
//            for (int j = 0; j < meshWidth; j++) {
//                int idx = i * meshWidth + j;
//
//                // 获取规则网格位置（和 GetStabilizedMesh() 一样）
//                cv::Point2f regularPos = meshflow.GetMesh()->getVertex(i, j);
//                cv::Point2f C_t = meshflow.m_vertexProfiles[idx].cumulativePath[t];
//
//                // Frame t 的实际顶点位置 = 规则位置 + 累积路径
//                cv::Point2f actualPos = regularPos + C_t;
//
//                originalMesh->xMat.at<double>(i, j) = actualPos.x;
//                originalMesh->yMat.at<double>(i, j) = actualPos.y;
//            }
//        }
//
//
//        // 2. 生成平滑后的网格
//        Mesh* smoothedMesh = meshflow.GetStabilizedMesh(t);
//
//        // 3. 绘制对比图
//        cv::Mat visOriginal = frames[t].clone();
//        cv::Mat visSmoothed = frames[t].clone();
//
//        originalMesh->drawMesh(visOriginal);
//        smoothedMesh->drawMesh(visSmoothed);
//
//        // 4. 拼接成对比图
//        cv::Mat comparison;
//        cv::hconcat(visOriginal, visSmoothed, comparison);
//
//        // 添加文字标注
//        cv::putText(comparison, "Original C(t)", cv::Point(50, 50),
//            cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 255, 0), 3);
//        cv::putText(comparison, "Smoothed P(t)", cv::Point(width + 50, 50),
//            cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 0, 255), 3);
//
//        //【路径】输出
//        string filename = "./output_frames/comparison_frame_" + to_string(t) + ".jpg";
//        cv::imwrite(filename, comparison);
//        cout << "Saved comparison: " << filename << "\n";
//
//        delete originalMesh;
//        delete smoothedMesh;
//    }
//
//    cout << "\n========== Test Completed ==========\n";
//    cout << "Check the comparison images:\n";
//    cout << "  - LEFT (green): Original cumulative path C(t) - should be curved/distorted\n";
//    cout << "  - RIGHT (red): Smoothed path P(t) - should be more straight/regular\n";
//    cout << "\nIf smoothing is working correctly:\n";
//    cout << "  1. Right side should be LESS curved than left side\n";
//    cout << "  2. Average smoothing displacement should be > 0\n";
//    cout << "  3. Different vertices should have different displacements\n";
//
//    cout << "\nPress any key to exit...\n";
//    cv::waitKey(0);
//
//    return 0;
//}
