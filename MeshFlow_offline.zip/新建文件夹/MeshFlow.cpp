﻿#include "MeshFlow.h"

//传入像素长宽值
MeshFlow::MeshFlow(int width, int height) {
	m_height = height;
	m_width = width;

	//【参数】网格设置
	/*m_quadWidth = 1.0 * m_width / pow(2.0, 3);
	m_quadHeight = 1.0 * m_height / pow(2.0, 3);*/

	
	m_quadWidth = 192;
	m_quadHeight = 108;
	cout << "=================网格设置=================" << endl;
	cout << " m_quadWidth:" << m_quadWidth << " m_quadHeight:" << m_quadHeight << endl;
	cout << "==========================================" << endl<<endl;

	m_mesh = new Mesh(m_height, m_width, m_quadWidth, m_quadHeight);
	m_warpedmesh = new Mesh(m_height, m_width, m_quadWidth, m_quadHeight);

	m_meshheight = m_mesh->height;
	m_meshwidth = m_mesh->width;
	m_vertexMotion.resize(m_meshheight * m_meshwidth);

	// ========== 新增：初始化 vertex profiles ==========
	m_vertexProfiles.resize(m_meshheight * m_meshwidth);
	m_frameCount = 0;

	std::cout << "MeshFlow initialized: " << m_meshwidth << "x" << m_meshheight
		<< " vertices" << std::endl;
}


//重置运动向量/特征点
void MeshFlow::ReInitialize() {
	for (int i = 0; i < m_meshheight * m_meshwidth; i++) m_vertexMotion[i].x = m_vertexMotion[i].y = 0;
	n.features.clear();
	n.motions.clear();
}

//输入匹配的特征点对，计算全局单应性矩阵
void MeshFlow::SetFeature(vector<cv::Point2f>& spt, vector<cv::Point2f>& tpt) {

	n.features = tpt;
	n.motions.resize(tpt.size());

	for (int i = 0; i < tpt.size(); i++) {
		/*n.motions[i] = spt[i] - tpt[i];*/
		n.motions[i] = tpt[i] - spt[i];  //修正：目标 - 起始

	}
	m_globalHomography = cv::findHomography(cv::Mat(spt), cv::Mat(tpt), cv::LMEDS);
}

//【修改】
void MeshFlow::SetSource(cv::Mat& src) {
	m_source = src.clone();
}

//【核心】核心执行函数
//完成从特征点运动信息到网格顶点运动的分配、空间滤波平滑，最终生成变形后的网格
void MeshFlow::Execute() {
	//将特征点的运动信息分配到网格的每个顶点，并通过中值滤波去除异常值，得到初始的网格顶点运动向量
	//分配运动到网格顶点_中值滤波器
	DistributeMotion2MeshVertexes_MedianFilter();  //the first median filter
	//空间中值滤波器
	SpatialMedianFilter(); //the second median filter

	WarpMeshbyMotion();
}

//【 MeshFlow::Execute()调用】分配运动到网格顶点_中值滤波器
void MeshFlow::DistributeMotion2MeshVertexes_MedianFilter() {

	//1.全局单应性变换初始化顶点运动
	//先通过全局单应性矩阵（m_globalHomography）计算每个网格顶点的初始运动向量（顶点原始位置 - 单应性变换后的位置）
	for (int i = 0; i < m_meshheight; i++) {
		for (int j = 0; j < m_meshwidth; j++) {
			cv::Point2f pt = m_mesh->getVertex(i, j);
			cv::Point2f pttrans = Trans(m_globalHomography, pt);
			/*m_vertexMotion[i * m_meshwidth + j].x = pt.x - pttrans.x;
			m_vertexMotion[i * m_meshwidth + j].y = pt.y - pttrans.y;*/
			m_vertexMotion[i * m_meshwidth + j].x = pttrans.x - pt.x;
			m_vertexMotion[i * m_meshwidth + j].y = pttrans.y - pt.y;
		}
	}

	vector<vector<float>> motionx, motiony;
	motionx.resize(m_meshheight * m_meshwidth);
	motiony.resize(m_meshheight * m_meshwidth);

	//2.特征点运动分配
	// 遍历每个网格顶点，寻找距离该顶点在 RADIUS范围内的特征点，将这些特征点的运动信息（n.motions）收集到顶点对应的运动列表中
	//distribute features motion to mesh vertexes
	for (int i = 0; i < m_meshheight; i++) {
		for (int j = 0; j < m_meshwidth; j++) {
			cv::Point2f pt = m_mesh->getVertex(i, j);

			for (int k = 0; k < n.features.size(); k++) {
				cv::Point2f pt2 = n.features[k];
				float dis = sqrt((pt.x - pt2.x) * (pt.x - pt2.x) + (pt.y - pt2.y) * (pt.y - pt2.y));

				float w = 1.0 / dis;
				if (dis > 1e-6f && dis < RADIUS) {
					motionx[i * m_meshwidth + j].push_back(n.motions[k].x);
					motiony[i * m_meshwidth + j].push_back(n.motions[k].y);
				}
			}
		}
	}
	//3.中值滤波器
//对每个顶点的运动列表（x/y 方向）执行快速排序，取中位数作为该顶点的最终初始运动向量
	for (int i = 0; i < m_meshheight; i++) {
		for (int j = 0; j < m_meshwidth; j++) {
			if (motionx[i * m_meshwidth + j].size() > 1) {
				myQuickSort(motionx[i * m_meshwidth + j], 0, motionx[i * m_meshwidth + j].size() - 1);
				myQuickSort(motiony[i * m_meshwidth + j], 0, motiony[i * m_meshwidth + j].size() - 1);
				m_vertexMotion[i * m_meshwidth + j].x = motionx[i * m_meshwidth + j][motionx[i * m_meshwidth + j].size() / 2];
				m_vertexMotion[i * m_meshwidth + j].y = motiony[i * m_meshwidth + j][motiony[i * m_meshwidth + j].size() / 2];
			}
		}
	}

	//【调试输出】
	//std::cout << "[DistributeMotion] Statistics:\n";
	//int nonZeroCount = 0;
	//double maxMotion = 0;
	//double avgMotion = 0;

	//for (int i = 0; i < m_meshheight; i++) {
	//	for (int j = 0; j < m_meshwidth; j++) {
	//		cv::Point2f motion = m_vertexMotion[i * m_meshwidth + j];
	//		double mag = cv::norm(motion);

	//		if (mag > 0.01) nonZeroCount++;
	//		maxMotion = std::max(maxMotion, mag);
	//		avgMotion += mag;
	//	}
	//}

	//avgMotion /= (m_meshheight * m_meshwidth);

	//std::cout << "  Non-zero vertices: " << nonZeroCount << " / "
	//	<< (m_meshheight * m_meshwidth) << "\n";
	//std::cout << "  Max motion: " << maxMotion << " pixels\n";
	//std::cout << "  Avg motion: " << avgMotion << " pixels\n";

}

//【MeshFlow::Execute()调用】空间中值滤波
//对第一步得到的网格顶点运动向量做空间域的中位数滤波（二次平滑），进一步消除局部噪声，保证网格运动的空间连续性
void MeshFlow::SpatialMedianFilter() {

	//1.先拷贝当前所有顶点的运动向量到临时数组tempVertexMotion，避免滤波过程中覆盖原始值
	VecPt2f tempVertexMotion(m_meshheight * m_meshwidth);//临时数组
	for (int i = 0; i < m_meshheight; i++) {
		for (int j = 0; j < m_meshwidth; j++) {
			tempVertexMotion[i * m_meshwidth + j] = m_vertexMotion[i * m_meshwidth + j];
		}
	}

	//2.定义滤波半径 radius=5，对每个网格顶点，收集其周围 ±5 范围内所有顶点的运动向量（x/y 方向）
	//【参数】网格顶点的滤波半径
	int radius = 5;
	for (int i = 0; i < m_meshheight; i++) {
		for (int j = 0; j < m_meshwidth; j++) {

			vector<float> motionx;//x运动方向
			vector<float> motiony;//y运动方向
			for (int k = -radius; k <= radius; k++) {
				for (int l = -radius; l <= radius; l++) {
					int ni = i + k;  //邻域行坐标
					int nj = j + l;  //邻域列坐标
					if (ni >= 0 && ni < m_meshheight && nj >= 0 && nj < m_meshwidth) {  // 判断邻域是否越界
						motionx.push_back(tempVertexMotion[ni * m_meshwidth + nj].x);  // 取邻域运动
						motiony.push_back(tempVertexMotion[ni * m_meshwidth + nj].y);  // 取邻域运动
					}
				}
			}

			//3.对收集到的邻域运动向量执行快速排序（myQuickSort），取中位数更新当前顶点的运动向量，实现空间平滑
			myQuickSort(motionx, 0, motionx.size() - 1);
			myQuickSort(motiony, 0, motiony.size() - 1);
			m_vertexMotion[i * m_meshwidth + j].x = motionx[motionx.size() / 2];
			m_vertexMotion[i * m_meshwidth + j].y = motiony[motiony.size() / 2];
		}
	}

	////【调试输出】
	//std::cout << "[SpatialMedianFilter] After filtering:\n";
	//int nonZeroCount = 0;
	//double maxMotion = 0;
	//double avgMotion = 0;

	//for (int i = 0; i < m_meshheight; i++) {
	//	for (int j = 0; j < m_meshwidth; j++) {
	//		cv::Point2f motion = m_vertexMotion[i * m_meshwidth + j];
	//		double mag = cv::norm(motion);

	//		if (mag > 0.01) nonZeroCount++;
	//		maxMotion = std::max(maxMotion, mag);
	//		avgMotion += mag;
	//	}
	//}

	//avgMotion /= (m_meshheight * m_meshwidth);

	//std::cout << "  Non-zero vertices: " << nonZeroCount << " / "
	//	<< (m_meshheight * m_meshwidth) << "\n";
	//std::cout << "  Max motion: " << maxMotion << " pixels\n";
	//std::cout << "  Avg motion: " << avgMotion << " pixels\n";

}

//【MeshFlow::Execute()调用】更新网格
//根据滤波后的顶点运动向量，更新 m_warpedmesh（变形后的网格）的顶点位置，完成网格的最终变形
void MeshFlow::WarpMeshbyMotion() {

	for (int i = 0; i < m_meshheight; i++) {
		for (int j = 0; j < m_meshwidth; j++) {
			cv::Point2f s = m_mesh->getVertex(i, j);
			s += m_vertexMotion[i * m_meshwidth + j];
			m_warpedmesh->setVertex(i, j, s);
		}
	}
}

//【可选输出】输出方法1
//计算每个像素的运动向量（生成 mapX/mapY 用于 remap）
void MeshFlow::GetMotions(cv::Mat& mapX, cv::Mat& mapY) {

	//【调试输出】
	/*std::cout << "\n=== GetMotions() START ===" << std::endl;
	std::cout << "m_width=" << m_width << ", m_height=" << m_height << std::endl;
	std::cout << "m_mesh size: " << m_mesh->width << "x" << m_mesh->height << std::endl;*/

	mapX = cv::Mat::zeros(m_height, m_width, CV_32FC1);
	mapY = cv::Mat::zeros(m_height, m_width, CV_32FC1);

	vector<cv::Point2f> source(4);
	vector<cv::Point2f> target(4);
	cv::Mat H;

	for (int i = 1; i < m_mesh->height; i++)
	{
		for (int j = 1; j < m_mesh->width; j++)
		{
			Quad s = m_mesh->getQuad(i, j);
			Quad t = m_warpedmesh->getQuad(i, j);

			source[0] = s.V00;
			source[1] = s.V01;
			source[2] = s.V10;
			source[3] = s.V11;

			target[0] = t.V00;
			target[1] = t.V01;
			target[2] = t.V10;
			target[3] = t.V11;

			H = cv::findHomography(source, target, 0);

			// 找到四个顶点的边界
			float min_x = std::min({ source[0].x, source[1].x, source[2].x, source[3].x });
			float max_x = std::max({ source[0].x, source[1].x, source[2].x, source[3].x });
			float min_y = std::min({ source[0].y, source[1].y, source[2].y, source[3].y });
			float max_y = std::max({ source[0].y, source[1].y, source[2].y, source[3].y });

			int y_start = std::max(0, (int)std::floor(min_y));
			int y_end = std::min(m_height, (int)std::ceil(max_y));
			int x_start = std::max(0, (int)std::floor(min_x));
			int x_end = std::min(m_width, (int)std::ceil(max_x));

			/*for (int ii = y_start; ii < y_end; ii++) {
				for (int jj = x_start; jj < x_end; jj++) {
					double x = 1.0 * jj;
					double y = 1.0 * ii;

					double X = H.at<double>(0, 0) * x + H.at<double>(0, 1) * y + H.at<double>(0, 2);
					double Y = H.at<double>(1, 0) * x + H.at<double>(1, 1) * y + H.at<double>(1, 2);
					double W = H.at<double>(2, 0) * x + H.at<double>(2, 1) * y + H.at<double>(2, 2);

					W = W ? 1.0 / W : 0;
					mapX.at<float>(ii, jj) = X * W - jj;
					mapY.at<float>(ii, jj) = Y * W - ii;
					
				}
			}*/
			for (int ii = y_start; ii < y_end; ii++) {
				for (int jj = x_start; jj < x_end; jj++) {
					double x = 1.0 * jj;
					double y = 1.0 * ii;

					double X = H.at<double>(0, 0) * x + H.at<double>(0, 1) * y + H.at<double>(0, 2);
					double Y = H.at<double>(1, 0) * x + H.at<double>(1, 1) * y + H.at<double>(1, 2);
					double W = H.at<double>(2, 0) * x + H.at<double>(2, 1) * y + H.at<double>(2, 2);

					W = W ? 1.0 / W : 0;

					//【调试输出】
					if (ii >= mapX.rows || jj >= mapX.cols) {
						static bool first_error = true;
						if (first_error) {
							/*std::cout << "\n!!! BOUNDARY ERROR !!!" << std::endl;
							std::cout << "ii=" << ii << ", jj=" << jj
								<< " | mapX.size=" << mapX.rows << "x" << mapX.cols << std::endl;
							std::cout << "m_height=" << m_height << ", m_width=" << m_width << std::endl;
							std::cout << "y_range=[" << y_start << "," << y_end
								<< "], x_range=[" << x_start << "," << x_end << "]" << std::endl;
							std::cout << "source: [0]=" << source[0] << " [1]=" << source[1]
								<< " [2]=" << source[2] << " [3]=" << source[3] << std::endl;*/
							first_error = false;
						}
						continue;
					}

					mapX.at<float>(ii, jj) = X * W - jj;
					mapY.at<float>(ii, jj) = Y * W - ii;
				}
			}


		}
	}
}



//【可选输出】输出方法2（图像）
void MeshFlow::GetWarpedSource(cv::Mat& dst, cv::Mat& mapX, cv::Mat& mapY) {
	meshWarpRemap(m_source, dst, mapX, mapY, *m_mesh, *m_warpedmesh);
}

cv::Point2f MeshFlow::Trans(cv::Mat H, cv::Point2f& pt) {
	cv::Point2f result;

	double a = H.at<double>(0, 0) * pt.x + H.at<double>(0, 1) * pt.y + H.at<double>(0, 2);
	double b = H.at<double>(1, 0) * pt.x + H.at<double>(1, 1) * pt.y + H.at<double>(1, 2);
	double c = H.at<double>(2, 0) * pt.x + H.at<double>(2, 1) * pt.y + H.at<double>(2, 2);

	result.x = a / c;
	result.y = b / c;

	return result;
}

// ========== 添加一帧的处理结果 ==========
void MeshFlow::AddFrame(Mesh* originalMesh, Mesh* warpedMesh) {
	std::cout << "\n========== [AddFrame] Start ==========" << std::endl;

	// 使用拷贝构造函数
	Mesh* origCopy = new Mesh(*originalMesh);
	Mesh* warpCopy = new Mesh(*warpedMesh);

	m_meshSequence.push_back(origCopy);
	m_warpedMeshSequence.push_back(warpCopy);

	std::cout << "Frame " << m_meshSequence.size() << " added to sequence" << std::endl;
	std::cout << "========== [AddFrame] End ==========\n" << std::endl;
}

// ========== 清空所有帧数据 ==========
void MeshFlow::ClearFrames() {
	for (auto mesh : m_meshSequence) delete mesh;
	for (auto mesh : m_warpedMeshSequence) delete mesh;
	for (auto mesh : m_smoothedMeshSequence) delete mesh;

	m_meshSequence.clear();
	m_warpedMeshSequence.clear();
	m_smoothedMeshSequence.clear();
}

// ========== 路径优化（核心算法） ==========
void MeshFlow::OptimizePath(double lambda, int radius) {
	int numFrames = m_meshSequence.size();
	if (numFrames == 0) {
		std::cerr << "Error: No frames to optimize!" << std::endl;
		return;
	}

	std::cout << "Optimizing camera path for " << numFrames << " frames..." << std::endl;
	std::cout << "  Lambda: " << lambda << ", Radius: " << radius << std::endl;

	m_lambda = lambda;
	m_radius = radius;

	//清空之前的优化结果
	for (auto mesh : m_smoothedMeshSequence) delete mesh;
	m_smoothedMeshSequence.clear();

	//为每一帧创建优化后的网格
	for (int t = 0; t < numFrames; t++) {
		//使用拷贝构造函数，直接复制原网格的所有参数
		Mesh* smoothedMesh = new Mesh(*m_meshSequence[t]);

		//对每个顶点进行优化
		for (int i = 0; i < m_meshheight; i++) {
			for (int j = 0; j < m_meshwidth; j++) {
				cv::Point2f optimizedPos = OptimizeVertexPath(t, i, j);
				smoothedMesh->setVertex(i, j, optimizedPos);
			}
		}

		m_smoothedMeshSequence.push_back(smoothedMesh);
	}

	std::cout << "Path optimization completed for " << numFrames << " frames" << std::endl;
}


// ========== 优化单个顶点的路径（Omega 优化） ==========
cv::Point2f MeshFlow::OptimizeVertexPath(int frameIdx, int i, int j) {
	int numFrames = m_meshSequence.size();

	// 获取原始位置和变形后的位置
	cv::Point2f originalPos = m_meshSequence[frameIdx]->getVertex(i, j);
	cv::Point2f warpedPos = m_warpedMeshSequence[frameIdx]->getVertex(i, j);

	// 如果是第一帧，直接使用变形后的位置
	if (frameIdx == 0) {
		return warpedPos;
	}

	// 计算时间窗口
	int startFrame = std::max(0, frameIdx - m_radius);
	int endFrame = std::min(numFrames - 1, frameIdx + m_radius);

	// ========== Omega 优化公式 ==========
	// 目标：最小化 E = E_data + λ * E_smooth
	// E_data = ||p_t - p_t'||^2  （数据项：保持变形效果）
	// E_smooth = Σ ||p_t - p_{t-1}||^2  （平滑项：保持路径平滑）

	cv::Point2f smoothedPos = warpedPos;

	//简化版本：加权平均（时间窗口内的平滑）
	double totalWeight = 1.0;
	cv::Point2f weightedSum = warpedPos;

	for (int t = startFrame; t <= endFrame; t++) {
		if (t == frameIdx) continue;

		// 计算时间距离权重
		double timeDist = std::abs(t - frameIdx);
		double weight = m_lambda * exp(-timeDist / m_radius);

		cv::Point2f neighborPos = m_warpedMeshSequence[t]->getVertex(i, j);
		weightedSum += weight * neighborPos;
		totalWeight += weight;
	}

	smoothedPos = weightedSum / totalWeight;

	return smoothedPos;
}

// ========== 获取优化后的映射表 ==========
void MeshFlow::GetSmoothedMotions(int frameIdx, cv::Mat& mapx, cv::Mat& mapy) {
	if (frameIdx < 0 || frameIdx >= m_smoothedMeshSequence.size()) {
		std::cerr << "Error: Invalid frame index " << frameIdx << std::endl;
		return;
	}

	mapx.create(m_height, m_width, CV_32FC1);  // ← 改为 m_height, m_width
	mapy.create(m_height, m_width, CV_32FC1);  // ← 改为 m_height, m_width

	Mesh* smoothedMesh = m_smoothedMeshSequence[frameIdx];

	// 使用优化后的网格生成映射表
	for (int i = 0; i < smoothedMesh->height - 1; i++) {
		for (int j = 0; j < smoothedMesh->width - 1; j++) {
			// 获取四个顶点的优化后位置
			cv::Point2f src[4], dst[4];

			src[0] = m_meshSequence[frameIdx]->getVertex(i, j);
			src[1] = m_meshSequence[frameIdx]->getVertex(i, j + 1);
			src[2] = m_meshSequence[frameIdx]->getVertex(i + 1, j + 1);
			src[3] = m_meshSequence[frameIdx]->getVertex(i + 1, j);

			dst[0] = smoothedMesh->getVertex(i, j);
			dst[1] = smoothedMesh->getVertex(i, j + 1);
			dst[2] = smoothedMesh->getVertex(i + 1, j + 1);
			dst[3] = smoothedMesh->getVertex(i + 1, j);

			// 计算单应性矩阵
			cv::Mat H = cv::getPerspectiveTransform(dst, src);

			// 填充映射表
			int startY = i * m_quadHeight;
			int endY = std::min((int)((i + 1) * m_quadHeight), m_height);  
			int startX = j * m_quadWidth;
			int endX = std::min((int)((j + 1) * m_quadWidth), m_width); 

			for (int y = startY; y < endY; y++) {
				for (int x = startX; x < endX; x++) {
					cv::Mat pt = (cv::Mat_<double>(3, 1) << x, y, 1);
					cv::Mat transformed = H * pt;

					double w = transformed.at<double>(2, 0);
					mapx.at<float>(y, x) = transformed.at<double>(0, 0) / w;
					mapy.at<float>(y, x) = transformed.at<double>(1, 0) / w;
				}
			}
		}
	}
}

// ================================新增=====================================
// 
//
// 在 Execute() 之后调用，将当前帧的运动向量添加到 vertex profiles
void MeshFlow::AddFrameMotion() {
	std::cout << "Adding frame " << m_frameCount << " motions...";

	//【调试输出】==========
	/*if (m_frameCount == 0) {
		std::cout << "\n========== Debug: Frame 0 Motion Vectors ==========\n";
		for (int idx = 0; idx < 5; idx++) {
			cv::Point2f v_t = m_vertexMotion[idx];
			std::cout << "Vertex " << idx << " motion: (" << v_t.x << ", " << v_t.y << ")\n";
		}
		std::cout << "================================================\n";
	}*/
	// 结束 ==========

    for (int i = 0; i < m_meshheight; i++) {
        for (int j = 0; j < m_meshwidth; j++) {
            int idx = i * m_meshwidth + j;

            cv::Point2f v_t = m_vertexMotion[idx];
            m_vertexProfiles[idx].motionVectors.push_back(v_t);

            if (m_frameCount == 0) {
                // 第一次调用：添加 Frame 0
                m_vertexProfiles[idx].cumulativePath.push_back(cv::Point2f(0, 0));
            }
            
            // 添加 Frame t+1 的累积路径
            cv::Point2f C_prev = m_vertexProfiles[idx].cumulativePath.back();
            cv::Point2f C_t = C_prev + v_t;
            m_vertexProfiles[idx].cumulativePath.push_back(C_t);
        }
    }

    m_frameCount++;
    std::cout << " Done. Total frames: " << m_frameCount << std::endl;
}


// 根据全局单应性矩阵预测 lambda_t（公式 2-3）
double MeshFlow::PredictLambda() {
	if (m_globalHomography.empty()) {
		return 100.0;  // 默认值
	}

	// 提取平移分量 T_v = sqrt(v_x^2 + v_y^2)
	double v_x = m_globalHomography.at<double>(0, 2);
	double v_y = m_globalHomography.at<double>(1, 2);

	// 归一化
	v_x /= m_width;
	v_y /= m_height;

	double T_v = sqrt(v_x * v_x + v_y * v_y);

	// 提取仿射部分（2x2 矩阵）
	cv::Mat affine = m_globalHomography(cv::Rect(0, 0, 2, 2)).clone();
	cv::Mat eigenvalues;
	cv::eigen(affine.t() * affine, eigenvalues);  // 计算特征值

	double e1 = sqrt(eigenvalues.at<double>(0, 0));
	double e2 = sqrt(eigenvalues.at<double>(1, 0));
	double F_a = std::min(e1, e2) / std::max(e1, e2);  // 比值

	// 公式 (2) 和 (3)
	double lambda_t_prime = -1.93 * T_v + 0.95;
	double lambda_t_double_prime = 5.83 * F_a + 4.88;

	// 取较小值，并限制在 [0, +∞)
	double lambda_t = std::max(0.0, std::min(lambda_t_prime, lambda_t_double_prime));

	std::cout << "Predicted lambda_t: " << lambda_t
		<< " (T_v=" << T_v << ", F_a=" << F_a << ")" << std::endl;

	return lambda_t;
}

// 离线平滑（公式 1）- 用于批处理模式
void MeshFlow::SmoothPathsOffline(double lambda, int radius) {
	if (m_frameCount == 0) {
		std::cerr << "Error: No frames to smooth!" << std::endl;
		return;
	}

	std::cout << "Smoothing paths (offline) for " << m_frameCount << " frames..." << std::endl;
	std::cout << "  Lambda: " << lambda << ", Radius: " << radius << std::endl;

	// 对每个顶点独立平滑
	for (int idx = 0; idx < m_vertexProfiles.size(); idx++) {
		VertexProfile& profile = m_vertexProfiles[idx];

		// 初始化：P(t) = C(t)
		profile.smoothedPath.clear();
		profile.smoothedPath.resize(m_frameCount);
		for (int t = 0; t < m_frameCount; t++) {
			profile.smoothedPath[t] = profile.cumulativePath[t];
		}

		// 迭代优化（5-10 次）
		for (int iter = 0; iter < 10; iter++) {
			std::vector<cv::Point2f> newSmoothedPath(m_frameCount);

			for (int t = 0; t < m_frameCount; t++) {
				cv::Point2f C_t = profile.cumulativePath[t];

				// 第一项：||P(t) - C(t)||^2
				double totalWeight = 1.0;
				cv::Point2f weightedSum = C_t;

				// 第二项：λ Σ w_{t,r} ||P(t) - P(r)||^2
				int startFrame = std::max(0, t - radius);
				int endFrame = std::min(m_frameCount - 1, t + radius);

				for (int r = startFrame; r <= endFrame; r++) {
					if (r == t) continue;

					double timeDist = std::abs(r - t);
					double sigma = radius / 3.0;
					double w_tr = exp(-timeDist * timeDist / (sigma * sigma));
					double weight = lambda * w_tr;

					// ✅ 用上一次迭代的 P(r)，不是 C(r)
					cv::Point2f P_r = profile.smoothedPath[r];
					weightedSum += weight * P_r;
					totalWeight += weight;
				}

				// 优化结果 P(t)
				newSmoothedPath[t] = weightedSum / totalWeight;
			}

			// 更新平滑路径
			profile.smoothedPath = newSmoothedPath;
		}
	}

	std::cout << "Path smoothing completed." << std::endl;
}


// 在线平滑（公式 4）- PAPS
void MeshFlow::SmoothPathsOnline(int bufferSize, double beta) {
	if (m_frameCount == 0) return;

	// 定义缓冲区范围
	int bufferStart = std::max(0, m_frameCount - bufferSize);
	int bufferEnd = m_frameCount - 1;  // 当前帧（incoming frame）

	std::cout << "Smoothing online [" << bufferStart << ", " << bufferEnd << "]" << std::endl;

	// 预测当前帧的 lambda_t
	double lambda_t = PredictLambda();
	m_lambdaHistory.push_back(lambda_t);

	// 对每个顶点独立优化
	for (int idx = 0; idx < m_vertexProfiles.size(); idx++) {
		VertexProfile& profile = m_vertexProfiles[idx];

		// 确保 smoothedPath 有足够空间
		if (profile.smoothedPath.size() < m_frameCount) {
			profile.smoothedPath.resize(m_frameCount);
		}

		// 优化缓冲区内的所有帧
		for (int t = bufferStart; t <= bufferEnd; t++) {
			cv::Point2f C_t = profile.cumulativePath[t];

			double totalWeight = 1.0;
			cv::Point2f weightedSum = C_t;

			// 第二项：时间平滑
			double lambda = (t < m_lambdaHistory.size()) ? m_lambdaHistory[t] : lambda_t;
			int radius = 40;  // 论文中的默认值

			for (int r = bufferStart; r <= bufferEnd; r++) {
				if (r == t) continue;

				double timeDist = std::abs(r - t);
				double sigma = radius / 3.0;
				double w_tr = exp(-timeDist * timeDist / (sigma * sigma));
				double weight = lambda * w_tr;

				cv::Point2f C_r = profile.cumulativePath[r];
				weightedSum += weight * C_r;
				totalWeight += weight;
			}

			// 第三项：与前一次优化的一致性（除了最后一帧）
			if (t < bufferEnd && m_frameCount > 1) {
				int prevIdx = idx * m_frameCount + t;
				if (!m_previousSmoothedPath.empty() && prevIdx < m_previousSmoothedPath.size()) {
					cv::Point2f P_prev = m_previousSmoothedPath[prevIdx];
					weightedSum += beta * P_prev;
					totalWeight += beta;
				}
			}

			profile.smoothedPath[t] = weightedSum / totalWeight;
		}
	}

	// 保存当前优化结果（用于下一次的第三项）
		// 保存当前优化结果（用于下一次的第三项）
	m_previousSmoothedPath.clear();
	for (int idx = 0; idx < m_vertexProfiles.size(); idx++) {
		for (int t = 0; t < m_frameCount; t++) {
			m_previousSmoothedPath.push_back(m_vertexProfiles[idx].smoothedPath[t]);
		}
	}

	std::cout << "Online smoothing completed for frame " << m_frameCount << std::endl;
}

 //生成用于 mesh warp 的源网格
Mesh* MeshFlow::GetStabilizedMesh(int frameIdx) {
	if (frameIdx >= m_frameCount || frameIdx < 0) {
		std::cerr << "Error: Invalid frame index " << frameIdx << std::endl;
		return nullptr;
	}

	if (m_vertexProfiles[0].smoothedPath.empty()) {
		std::cerr << "Error: Paths not smoothed yet!" << std::endl;
		return nullptr;
	}

	// 创建采样网格
	Mesh* samplingMesh = new Mesh(m_height, m_width, m_quadWidth, m_quadHeight);

	// 第一步：计算原始采样位置
	std::vector<cv::Point2f> rawSamplingPos(m_meshheight * m_meshwidth);

	for (int i = 0; i < m_meshheight; i++) {
		for (int j = 0; j < m_meshwidth; j++) {
			int idx = i * m_meshwidth + j;

			cv::Point2f regularPos = m_mesh->getVertex(i, j);
			cv::Point2f C_t = m_vertexProfiles[idx].cumulativePath[frameIdx];
			cv::Point2f P_t = m_vertexProfiles[idx].smoothedPath[frameIdx];
			cv::Point2f jitter = C_t - P_t;

			rawSamplingPos[idx] = regularPos + jitter;
		}
	}

	// 第二步：空间平滑（高斯滤波）
	std::vector<cv::Point2f> smoothedSamplingPos = rawSamplingPos;

	for (int i = 1; i < m_meshheight - 1; i++) {
		for (int j = 1; j < m_meshwidth - 1; j++) {
			int idx = i * m_meshwidth + j;

			// 3x3 高斯核（权重：中心 4，边 2，角 1）
			cv::Point2f sum(0, 0);
			float weightSum = 0;

			for (int di = -1; di <= 1; di++) {
				for (int dj = -1; dj <= 1; dj++) {
					int ni = i + di;
					int nj = j + dj;
					int nidx = ni * m_meshwidth + nj;

					float weight = (di == 0 && dj == 0) ? 4.0f :
						(di == 0 || dj == 0) ? 2.0f : 1.0f;

					sum += rawSamplingPos[nidx] * weight;
					weightSum += weight;
				}
			}

			smoothedSamplingPos[idx] = sum / weightSum;
		}
	}

	// 第三步：设置顶点并边界限制
	for (int i = 0; i < m_meshheight; i++) {
		for (int j = 0; j < m_meshwidth; j++) {
			int idx = i * m_meshwidth + j;

			cv::Point2f samplingPos = smoothedSamplingPos[idx];

			// 边界限制
			samplingPos.x = std::max(0.0f, std::min((float)(m_width - 1), samplingPos.x));
			samplingPos.y = std::max(0.0f, std::min((float)(m_height - 1), samplingPos.y));

			samplingMesh->setVertex(i, j, samplingPos);
		}
	}

	return samplingMesh;
}