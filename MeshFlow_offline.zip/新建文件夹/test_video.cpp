////ȫ�����������У�һ���Դ������ڴ�ռ�ô�
// 
//#include <opencv2/opencv.hpp>
//#include <iostream>
//#include <vector>
//#include "MeshFlow.h"
//#include "Mesh.h"
//
//using namespace std;
//
//int main() {
//    // ========== 1. ��ȡ��Ƶ ==========
//    string videoPath = "D:\\MVR_Project\\steady_image\\MeshFlow_testvideo\\720_2.mp4";
//    cv::VideoCapture cap(videoPath);
//
//    if (!cap.isOpened()) {
//        cerr << "Error: Cannot open video file" << endl;
//        return -1;
//    }
//
//    int width = cap.get(cv::CAP_PROP_FRAME_WIDTH);
//    int height = cap.get(cv::CAP_PROP_FRAME_HEIGHT);
//    int totalFrames = cap.get(cv::CAP_PROP_FRAME_COUNT);
//    double fps = cap.get(cv::CAP_PROP_FPS);
//
//    cout << "Video info:" << endl;
//    cout << "  Resolution: " << width << "x" << height << endl;
//    cout << "  Total frames: " << totalFrames << endl;
//    cout << "  FPS: " << fps << endl;
//
//    // ��ȡǰ 90 ֡����ȫ��֡��
//    /*int numFrames = min(90, totalFrames);*/
//    int numFrames = totalFrames;
//    vector<cv::Mat> frames;
//
//    cout << "\nReading frames..." << endl;
//    for (int i = 0; i < numFrames; i++) {
//        cv::Mat frame;
//        cap >> frame;
//        if (frame.empty()) break;
//        frames.push_back(frame.clone());
//
//        if (i % 10 == 0) {
//            cout << "  Read " << i << "/" << numFrames << " frames\r" << flush;
//        }
//    }
//    cap.release();
//
//    cout << "\nLoaded " << frames.size() << " frames\n" << endl;
//
//    // ========== 2. ��ʼ�� MeshFlow ==========
//    MeshFlow meshflow(width, height);
//
//    // ========== 3. ��������֡ ==========
//    cout << "========== Processing frames ==========" << endl;
//
//    for (int i = 0; i < frames.size() - 1; i++) {
//        cout << "Processing frame " << i << "/" << (frames.size() - 1) << "\r" << flush;
//
//        // ת��Ϊ�Ҷ�ͼ
//        cv::Mat gray0, gray1;
//        cv::cvtColor(frames[i], gray0, cv::COLOR_BGR2GRAY);
//        cv::cvtColor(frames[i + 1], gray1, cv::COLOR_BGR2GRAY);
//
//        // ��ȡ������
//        vector<cv::Point2f> prevPts, nextPts;
//        cv::goodFeaturesToTrack(gray0, prevPts, 500, 0.01, 10);
//
//        // �������
//        vector<uchar> status;
//        vector<float> err;
//        cv::calcOpticalFlowPyrLK(gray0, gray1, prevPts, nextPts, status, err);
//
//        // ������Ч������
//        vector<cv::Point2f> validPrev, validNext;
//        for (int j = 0; j < prevPts.size(); j++) {
//            if (status[j]) {
//                validPrev.push_back(prevPts[j]);
//                validNext.push_back(nextPts[j]);
//            }
//        }
//
//        // ���������㲢ִ�� MeshFlow
//        meshflow.ReInitialize();
//        meshflow.SetFeature(validPrev, validNext);
//        meshflow.Execute();
//
//        // ���ӵ��ۻ�·��
//        meshflow.AddFrameMotion();
//    }
//
//    cout << "\nFrame processing completed!" << endl;
//
//    // ========== 4. ִ��·��ƽ�� ==========
//    cout << "\n========== Smoothing paths ==========" << endl;
//    double lambda = 5.0;
//    int radius = 5;
//
//    meshflow.SmoothPathsOffline(lambda, radius);
//
//    cout << "Path smoothing completed!" << endl;
//    cout << "  Lambda: " << lambda << endl;
//    cout << "  Radius: " << radius << endl;
//
//    // ========== 5. �����ȶ�����Ƶ ==========
//    cout << "\n========== Generating stabilized video ==========" << endl;
//
//    string outputPath = "stabilized_output.avi";
//    cv::VideoWriter writer(outputPath, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'),
//        fps,
//        cv::Size(width, height));
//
//    if (!writer.isOpened()) {
//        cerr << "Error: Cannot create output video!" << endl;
//        return -1;
//    }
//
//    // ���������������� meshWarpRemap��
//    Mesh* regularMesh = meshflow.GetMesh();
//
//    for (int t = 0; t < frames.size(); t++) {
//        cout << "Stabilizing frame " << t << "/" << frames.size() << "\r" << flush;
//
//        // ��ȡ�ȶ�������
//        Mesh* stabilizedMesh = meshflow.GetStabilizedMesh(t);
//
//        if (stabilizedMesh == nullptr) {
//            cerr << "\nError: Failed to get stabilized mesh for frame " << t << endl;
//            continue;
//        }
//
//        // ����ӳ�����
//        cv::Mat mapX(height, width, CV_32FC1);
//        cv::Mat mapY(height, width, CV_32FC1);
//
//        // ʹ�� meshWarpRemap ����ӳ��
//        cv::Mat stabilizedFrame = frames[t].clone();
//        meshWarpRemap(frames[t], stabilizedFrame, mapX, mapY, *regularMesh, *stabilizedMesh);
//
//        // д����Ƶ
//        writer.write(stabilizedFrame);
//
//        delete stabilizedMesh;
//    }
//
//    writer.release();
//    cout << "\nStabilized video saved to: " << outputPath << endl;
//
//    // ========== 6. ���ɶԱ���Ƶ ==========
//    cout << "\n========== Generating comparison video ==========" << endl;
//
//    string comparisonPath = "comparison_output.avi";
//    cv::VideoWriter comparisonWriter(comparisonPath,
//        cv::VideoWriter::fourcc('M', 'J', 'P', 'G'),
//        fps,
//        cv::Size(width * 2, height));
//
//    if (!comparisonWriter.isOpened()) {
//        cerr << "Error: Cannot create comparison video!" << endl;
//        return -1;
//    }
//
//    for (int t = 0; t < frames.size(); t++) {
//        cout << "Creating comparison frame " << t << "/" << frames.size() << "\r" << flush;
//
//        // ��ȡ�ȶ�������
//        Mesh* stabilizedMesh = meshflow.GetStabilizedMesh(t);
//
//        if (stabilizedMesh == nullptr) {
//            continue;
//        }
//
//        // �����ȶ���֡
//        cv::Mat mapX(height, width, CV_32FC1);
//        cv::Mat mapY(height, width, CV_32FC1);
//        cv::Mat stabilizedFrame = frames[t].clone();
//        meshWarpRemap(frames[t], stabilizedFrame, mapX, mapY, *regularMesh, *stabilizedMesh);
//
//        // �����Ա�ͼ
//        cv::Mat comparison(height, width * 2, CV_8UC3);
//        frames[t].copyTo(comparison(cv::Rect(0, 0, width, height)));
//        stabilizedFrame.copyTo(comparison(cv::Rect(width, 0, width, height)));
//
//        // ���ӱ�ǩ
//        cv::putText(comparison, "Original", cv::Point(20, 50),
//            cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 255, 0), 3);
//        cv::putText(comparison, "Stabilized", cv::Point(width + 20, 50),
//            cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 0, 255), 3);
//
//        // ����֡��
//        string frameText = "Frame: " + to_string(t);
//        cv::putText(comparison, frameText, cv::Point(20, height - 20),
//            cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 255, 255), 2);
//
//        comparisonWriter.write(comparison);
//
//        delete stabilizedMesh;
//    }
//
//    comparisonWriter.release();
//    cout << "\nComparison video saved to: " << comparisonPath << endl;
//
//    cout << "\n========== All done! ==========" << endl;
//    cout << "Output files:" << endl;
//    cout << "  1. " << outputPath << " - Stabilized video only" << endl;
//    cout << "  2. " << comparisonPath << " - Side-by-side comparison" << endl;
//
//    return 0;
//}
