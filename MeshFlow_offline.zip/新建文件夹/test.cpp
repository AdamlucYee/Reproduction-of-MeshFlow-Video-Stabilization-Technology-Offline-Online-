﻿////检测运动估计是否起效
// 
//#include <opencv2/opencv.hpp>
//#include <iostream>
//#include "MeshFlow.h"
//#include "Mesh.h"
//
//int main() {
//    cv::utils::logging::setLogLevel(cv::utils::logging::LOG_LEVEL_ERROR);
//    // ========== 读取两帧 ==========
//    std::string videoPath = "D:\\MVR_Project\\steady_image\\MeshFlow_testvideo\\720_1.mp4";
//    cv::VideoCapture cap(videoPath);
//
//    if (!cap.isOpened()) {
//        std::cerr << "Error: Cannot open video!" << std::endl;
//        return -1;
//    }
//
//    int width = cap.get(cv::CAP_PROP_FRAME_WIDTH);
//    int height = cap.get(cv::CAP_PROP_FRAME_HEIGHT);
//
//    std::cout << "Video size: " << width << "x" << height << std::endl;
//
//    cv::Mat frame0, frame1;
//    cap >> frame0;
//    cap >> frame1;
//
//    for (int i = 0; i < 5; i++) {
//        cap >> frame1;
//    }
//
//    std::cout << "Testing motion between frame 0 and frame 5\n";
//
//    if (frame0.empty() || frame1.empty()) {
//        std::cerr << "Error: Cannot read frames!" << std::endl;
//        return -1;
//    }
//
//    // ========== 特征检测与跟踪 ==========
//    cv::Mat gray0, gray1;
//    cv::cvtColor(frame0, gray0, cv::COLOR_BGR2GRAY);
//    cv::cvtColor(frame1, gray1, cv::COLOR_BGR2GRAY);
//
//    std::vector<cv::Point2f> pts0;
//    cv::goodFeaturesToTrack(gray0, pts0, 1000, 0.01, 10);
//
//    std::vector<cv::Point2f> pts1;
//    std::vector<uchar> status;
//    std::vector<float> err;
//    cv::calcOpticalFlowPyrLK(gray0, gray1, pts0, pts1, status, err);
//
//    // 过滤有效特征点
//    std::vector<cv::Point2f> goodPts0, goodPts1;
//    for (size_t i = 0; i < status.size(); i++) {
//        if (status[i]) {
//            goodPts0.push_back(pts0[i]);
//            goodPts1.push_back(pts1[i]);
//        }
//    }
//
//    std::cout << "Tracked " << goodPts0.size() << " features" << std::endl;
//
//    // ========== MeshFlow 运动估计 ==========
//    MeshFlow meshflow(width, height);
//
//    std::cout << "\n========== Testing MeshFlow ==========\n";
//    std::cout << "Mesh size: " << meshflow.GetMesh()->width << "x"
//        << meshflow.GetMesh()->height << " vertices" << std::endl;
//    std::cout << "Quad size: " << meshflow.GetMesh()->quadWidth << "x"
//        << meshflow.GetMesh()->quadHeight << " pixels" << std::endl;
//
//    meshflow.ReInitialize();
//    meshflow.SetFeature(goodPts0, goodPts1);  // 注意：前一帧在前
//    meshflow.SetSource(frame1);
//    meshflow.Execute();
//
//    // ========== 检查结果 ==========
//    // ========== 可视化特征点运动 ==========
//    cv::Mat featureVis = frame0.clone();
//    double maxMotion = 0;
//    double avgMotion = 0;
//
//    for (size_t i = 0; i < goodPts0.size(); i++) {
//        cv::Point2f motion = goodPts1[i] - goodPts0[i];
//        double mag = cv::norm(motion);
//        maxMotion = std::max(maxMotion, mag);
//        avgMotion += mag;
//
//        // 绘制运动向量（放大 10 倍以便观察）
//        cv::arrowedLine(featureVis, goodPts0[i], goodPts0[i] + motion * 10,
//            cv::Scalar(0, 255, 0), 1, cv::LINE_AA, 0, 0.3);
//        cv::circle(featureVis, goodPts0[i], 3, cv::Scalar(0, 0, 255), -1);
//    }
//
//    avgMotion /= goodPts0.size();
//
//    std::cout << "\n========== Feature Motion Statistics ==========\n";
//    std::cout << "Max motion: " << maxMotion << " pixels\n";
//    std::cout << "Avg motion: " << avgMotion << " pixels\n";
//
//    cv::imshow("Feature Motion (10x magnified)", featureVis);
//
//
//
//    Mesh* originalMesh = meshflow.GetMesh();
//    Mesh* warpedMesh = meshflow.GetWarpedMesh();
//
//    double maxVertexMotion = 0;
//    double avgVertexMotion = 0;
//    int vertexCount = originalMesh->width * originalMesh->height;
//
//    for (int i = 0; i < originalMesh->height; i++) {
//        for (int j = 0; j < originalMesh->width; j++) {
//            cv::Point2f orig = originalMesh->getVertex(i, j);
//            cv::Point2f warped = warpedMesh->getVertex(i, j);
//            cv::Point2f motion = warped - orig;
//            double mag = cv::norm(motion);
//
//            maxVertexMotion = std::max(maxVertexMotion, mag);
//            avgVertexMotion += mag;
//
//            // 打印几个特殊顶点
//            if ((i == 0 && j == 0) || (i == 4 && j == 4) || (i == 8 && j == 8)) {
//                std::cout << "Vertex (" << i << ", " << j << "): motion = "
//                    << motion << ", mag = " << mag << "\n";
//            }
//        }
//    }
//
//    avgVertexMotion /= vertexCount;
//
//    std::cout << "\n========== Vertex Motion Statistics ==========\n";
//    std::cout << "Max vertex motion: " << maxVertexMotion << " pixels\n";
//    std::cout << "Avg vertex motion: " << avgVertexMotion << " pixels\n";
//    std::cout << "Feature avg motion: " << avgMotion << " pixels\n";
//    std::cout << "Ratio (vertex/feature): " << avgVertexMotion / avgMotion << "\n";
//
//    std::cout << "\n========== Checking mesh vertices ==========\n";
//
//    // 检查几个顶点
//    int checkPoints[][2] = { {0, 0}, {5, 5}, {10, 10} };
//
//    for (auto& pt : checkPoints) {
//        int i = pt[0];
//        int j = pt[1];
//
//        if (i >= originalMesh->height || j >= originalMesh->width) continue;
//
//        cv::Point2f orig = originalMesh->getVertex(i, j);
//        cv::Point2f warped = warpedMesh->getVertex(i, j);
//        cv::Point2f motion = warped - orig;
//
//        std::cout << "Vertex (" << i << ", " << j << "):\n";
//        std::cout << "  Original: " << orig << "\n";
//        std::cout << "  Warped:   " << warped << "\n";
//        std::cout << "  Motion:   " << motion << " (magnitude: "
//            << cv::norm(motion) << ")\n";
//    }
//
//    // ========== 可视化 ==========
//    // ========== 可视化 ==========
//    cv::Mat vis = frame0.clone();  // ✅ 只用一张图
//
//    // 绘制原始网格（绿色）
//    for (int i = 0; i < originalMesh->height; i++) {
//        for (int j = 0; j < originalMesh->width - 1; j++) {
//            cv::Point2f p1 = originalMesh->getVertex(i, j);
//            cv::Point2f p2 = originalMesh->getVertex(i, j + 1);
//            cv::line(vis, p1, p2, cv::Scalar(0, 255, 0), 2);  // 绿色，加粗
//        }
//    }
//
//    for (int j = 0; j < originalMesh->width; j++) {
//        for (int i = 0; i < originalMesh->height - 1; i++) {
//            cv::Point2f p1 = originalMesh->getVertex(i, j);
//            cv::Point2f p2 = originalMesh->getVertex(i + 1, j);
//            cv::line(vis, p1, p2, cv::Scalar(0, 255, 0), 2);  // 绿色，加粗
//        }
//    }
//
//    // 绘制变形后的网格（红色）- 叠加在同一张图上
//    for (int i = 0; i < warpedMesh->height; i++) {
//        for (int j = 0; j < warpedMesh->width - 1; j++) {
//            cv::Point2f p1 = warpedMesh->getVertex(i, j);
//            cv::Point2f p2 = warpedMesh->getVertex(i, j + 1);
//            cv::line(vis, p1, p2, cv::Scalar(0, 0, 255), 2);  // ✅ 红色，画在同一张图上
//        }
//    }
//
//    for (int j = 0; j < warpedMesh->width; j++) {
//        for (int i = 0; i < warpedMesh->height - 1; i++) {
//            cv::Point2f p1 = warpedMesh->getVertex(i, j);
//            cv::Point2f p2 = warpedMesh->getVertex(i + 1, j);
//            cv::line(vis, p1, p2, cv::Scalar(0, 0, 255), 2);  // ✅ 红色，画在同一张图上
//        }
//    }
//
//    // 显示
//    
//
//    // 在图像上显示统计信息
//    std::string text1 = "Avg vertex motion: " + std::to_string(avgVertexMotion) + " px";
//    std::string text2 = "Max vertex motion: " + std::to_string(maxVertexMotion) + " px";
//    cv::putText(vis, text1, cv::Point(10, 30), cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(255, 255, 255), 2);
//    cv::putText(vis, text2, cv::Point(10, 60), cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(255, 255, 255), 2);
//
//    cv::imshow("Mesh Deformation (Green=Original, Red=Warped)", vis);
//   
//
//    std::cout << "\nPress any key to exit..." << std::endl;
//    cv::waitKey(0);
//
//    return 0;
//}
