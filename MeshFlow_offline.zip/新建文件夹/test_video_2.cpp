// test_video.cpp - �޸ĺ�İ汾
#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include "MeshFlow.h"
#include "Mesh.h"

using namespace std;

int main(int argc, char** argv) {
    cv::utils::logging::setLogLevel(cv::utils::logging::LOG_LEVEL_WARNING);
    //�����롿
    string videoPath = "./test_video/1080_3.mp4";
    int maxFrames = -1;  // -1 ��ʾȫ��֡

    if (argc > 1) {
        videoPath = argv[1];
    }
    if (argc > 2) {
        maxFrames = atoi(argv[2]);
    }

    // ========== 1. ��ȡ��Ƶ��Ϣ ==========
    cv::VideoCapture cap(videoPath);

    if (!cap.isOpened()) {
        cerr << "Error: Cannot open video file" << endl;
        return -1;
    }

    int width = cap.get(cv::CAP_PROP_FRAME_WIDTH);
    int height = cap.get(cv::CAP_PROP_FRAME_HEIGHT);
    int totalFrames = cap.get(cv::CAP_PROP_FRAME_COUNT);
    double fps = cap.get(cv::CAP_PROP_FPS);

    cout << "Video info:" << endl;
    cout << "  Resolution: " << width << "x" << height << endl;
    cout << "  Total frames: " << totalFrames << endl;
    cout << "  FPS: " << fps << endl;

    // ȷ��Ҫ������֡��
    int numFrames = (maxFrames > 0) ? min(maxFrames, totalFrames) : totalFrames;
    cout << "  Processing frames: " << numFrames << endl;

    // ========== 2. ��ʼ�� MeshFlow ==========
    MeshFlow meshflow(width, height);

    // ========== 3. ��һ�飺��ȡ�˶���������֡�� ==========
    cout << "\n========== Pass 1: Extracting motion ==========\n";

    cv::Mat prevFrame, currFrame;
    cap >> prevFrame;

    for (int i = 0; i < numFrames - 1; i++) {
        cap >> currFrame;
        if (currFrame.empty()) break;

        cout << "Processing frame " << i << "/" << (numFrames - 1) << "\r" << flush;

        // ת��Ϊ�Ҷ�ͼ
        cv::Mat gray0, gray1;
        cv::cvtColor(prevFrame, gray0, cv::COLOR_BGR2GRAY);
        cv::cvtColor(currFrame, gray1, cv::COLOR_BGR2GRAY);

        // ��ȡ������
        vector<cv::Point2f> prevPts, nextPts;
        //������������������
        cv::goodFeaturesToTrack(gray0, prevPts, 500, 0.01, 10);

        // �������
        vector<uchar> status;
        vector<float> err;
        cv::calcOpticalFlowPyrLK(gray0, gray1, prevPts, nextPts, status, err);

        // ������Ч������
        vector<cv::Point2f> validPrev, validNext;
        for (int j = 0; j < prevPts.size(); j++) {
            if (status[j]) {
                validPrev.push_back(prevPts[j]);
                validNext.push_back(nextPts[j]);
            }
        }

        // ���������㲢ִ�� MeshFlow
        meshflow.ReInitialize();
        meshflow.SetFeature(validPrev, validNext);
        meshflow.Execute();
        meshflow.AddFrameMotion();
        // ����ǰһ֡
        prevFrame = currFrame.clone();
    }

    cout << "\nMotion extraction completed!\n";

    // ========== 4. ִ��·��ƽ�� ==========
    cout << "\n========== Smoothing paths ==========\n";
    //��������·��ƽ����Ȩ�أ����϶ȣ�
    double lambda = 20;
    //��������·����ʱ���˲�ǿ��
    int radius = 7;

    meshflow.SmoothPathsOffline(lambda, radius);

    cout << "Path smoothing completed!" << endl;
    cout << "  Lambda: " << lambda << endl;
    cout << "  Radius: " << radius << endl;

    // ========== 5. �ڶ��飺�����ȶ�����Ƶ ==========
    cout << "\n========== Pass 2: Generating stabilized video ==========\n";

    // ������Ƶ����ͷ
    cap.set(cv::CAP_PROP_POS_FRAMES, 0);

    // �޸����·���͸�ʽ
    string outputPath = "./output_video/stabilized_output.mp4";
    cv::VideoWriter writer(outputPath, cv::VideoWriter::fourcc('m', 'p', '4', 'v'),
        fps, cv::Size(width, height));

    if (!writer.isOpened()) {
        cerr << "Error: Cannot create output video!" << endl;
        return -1;
    }

    Mesh* regularMesh = meshflow.GetMesh();

    for (int t = 0; t < numFrames; t++) {
        cv::Mat frame;
        cap >> frame;
        if (frame.empty()) break;

        cout << "Stabilizing frame " << t << "/" << numFrames << "\r" << flush;

        Mesh* stabilizedMesh = meshflow.GetStabilizedMesh(t);

        if (stabilizedMesh == nullptr) {
            cerr << "\nError: Failed to get stabilized mesh for frame " << t << endl;
            writer.write(frame);  // д��ԭʼ֡
            continue;
        }

        cv::Mat mapX(height, width, CV_32FC1);
        cv::Mat mapY(height, width, CV_32FC1);
        cv::Mat stabilizedFrame = frame.clone();
        meshWarpRemap(frame, stabilizedFrame, mapX, mapY, *regularMesh, *stabilizedMesh);

        writer.write(stabilizedFrame);
        delete stabilizedMesh;
    }

    writer.release();
    cout << "\nStabilized video saved to: " << outputPath << endl;

    // ========== 6. ���ɶԱ���Ƶ ==========
    cout << "\n========== Generating comparison video ==========\n";

    cap.set(cv::CAP_PROP_POS_FRAMES, 0);  // ���õ���ͷ

    // �޸����·���͸�ʽ
    string comparisonPath = "./output_video/comparison_output.mp4";
    cv::VideoWriter comparisonWriter(comparisonPath,
        cv::VideoWriter::fourcc('m', 'p', '4', 'v'),
        fps, cv::Size(width * 2, height));

    if (!comparisonWriter.isOpened()) {
        cerr << "Error: Cannot create comparison video!" << endl;
        return -1;
    }

    for (int t = 0; t < numFrames; t++) {
        cv::Mat frame;
        cap >> frame;
        if (frame.empty()) break;

        cout << "Creating comparison frame " << t << "/" << numFrames << "\r" << flush;

        Mesh* stabilizedMesh = meshflow.GetStabilizedMesh(t);

        if (stabilizedMesh == nullptr) {
            continue;
        }

        cv::Mat mapX(height, width, CV_32FC1);
        cv::Mat mapY(height, width, CV_32FC1);
        cv::Mat stabilizedFrame = frame.clone();
        meshWarpRemap(frame, stabilizedFrame, mapX, mapY, *regularMesh, *stabilizedMesh);

        cv::Mat comparison(height, width * 2, CV_8UC3);
        frame.copyTo(comparison(cv::Rect(0, 0, width, height)));
        stabilizedFrame.copyTo(comparison(cv::Rect(width, 0, width, height)));

        cv::putText(comparison, "Original", cv::Point(20, 50),
            cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 255, 0), 3);
        cv::putText(comparison, "Stabilized", cv::Point(width + 20, 50),
            cv::FONT_HERSHEY_SIMPLEX, 1.5, cv::Scalar(0, 0, 255), 3);

        string frameText = "Frame: " + to_string(t);
        cv::putText(comparison, frameText, cv::Point(20, height - 20),
            cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(255, 255, 255), 2);

        comparisonWriter.write(comparison);
        delete stabilizedMesh;
    }

    comparisonWriter.release();
    cap.release();

    cout << "\nComparison video saved to: " << comparisonPath << endl;
    cout << "\n========== All done! ==========\n";

    return 0;
}